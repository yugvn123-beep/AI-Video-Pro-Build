package com.smartdailytools.aivideopro;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.media.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_VIDEO = 10, SAVE_VIDEO = 11, SAVE_AUDIO = 12, SAVE_IMAGE = 13, PICK_MERGE = 14, SAVE_MERGE = 15, SAVE_DELETE = 16;
    private final int purple = Color.rgb(124,58,237), ink = Color.rgb(15,11,31);
    private LinearLayout root, editorBox;
    private VideoView videoView;
    private SeekBar startBar, endBar;
    private TimelineView timeline;
    private TextView rangeLabel, status;
    private Uri sourceUri;
    private long durationMs;
    private CheckBox muteBox;
    private Spinner speedSpinner, rotateSpinner;
    private final ArrayList<Uri> mergeUris = new ArrayList<>();
    private Uri lastSavedUri;
    private final ArrayList<int[]> undoRanges=new ArrayList<>(), redoRanges=new ArrayList<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(ink);
        showHome();
    }

    private TextView text(String value, int sp, int color) {
        TextView v = new TextView(this); v.setText(value); v.setTextSize(sp); v.setTextColor(color);
        v.setGravity(Gravity.RIGHT); v.setPadding(12,10,12,10); return v;
    }

    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextSize(16); b.setTextColor(Color.WHITE);
        b.setBackgroundColor(purple); b.setAllCaps(false); b.setPadding(16,8,16,8);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(54)); p.setMargins(0,8,0,8); b.setLayoutParams(p); return b;
    }

    private Button toolButton(String label){
        Button b=new Button(this);b.setText(label);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setAllCaps(false);b.setGravity(Gravity.CENTER);
        b.setBackgroundColor(0xFF302843);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(112),dp(76));p.setMargins(dp(5),dp(6),dp(5),dp(6));b.setLayoutParams(p);return b;
    }

    private ArrayAdapter<String> darkSpinnerAdapter(String[] values){
        return new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,values){
            private TextView style(TextView v){v.setTextColor(Color.WHITE);v.setTextSize(16);v.setPadding(dp(16),dp(12),dp(16),dp(12));v.setBackgroundColor(0xFF302843);return v;}
            @Override public View getView(int p,View c,android.view.ViewGroup parent){return style((TextView)super.getView(p,c,parent));}
            @Override public View getDropDownView(int p,View c,android.view.ViewGroup parent){return style((TextView)super.getDropDownView(p,c,parent));}
        };
    }

    private void base(String title) {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(ink);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20),dp(22),dp(20),dp(30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); scroll.addView(root);
        TextView logo = text("✦  AI VIDEO PRO",22,Color.WHITE); logo.setTypeface(null,1); root.addView(logo);
        TextView h = text(title,28,Color.WHITE); h.setTypeface(null,1); h.setPadding(12,22,12,8); root.addView(h);
        setContentView(scroll);
    }

    private void showHome() {
        base("أنشئ فيديوك باحتراف");
        root.addView(text("مونتاج سريع وأدوات ذكاء اصطناعي مصممة للمحتوى العربي.",16,0xFFCCC6DD));
        Button edit = button("🎬  قص فيديو من الهاتف"); edit.setOnClickListener(v -> openPicker()); root.addView(edit);
        Button merge = button("🎞  دمج عدة فيديوهات"); merge.setOnClickListener(v -> openMergePicker()); root.addView(merge);
        Button ai = button("✨  توليد فيديو بالذكاء الاصطناعي"); ai.setOnClickListener(v -> showAi()); root.addView(ai);
        root.addView(text("أدوات الإصدار 2",19,Color.WHITE));
        root.addView(text("✓ اختيار الفيديو من المعرض أو الملفات\n✓ قص وكتم وتغيير السرعة والتدوير\n✓ دمج عدة فيديوهات\n✓ استخراج الصوت وصورة الغلاف\n✓ حفظ ومشاركة النتيجة\n✓ معالجة محلية دون رفع ملفاتك",16,0xFFE8E3F3));
        status = text("الرصيد التجريبي: فيديو AI واحد بعد تفعيل الخادم",14,0xFFBFA9FF); root.addView(status);
    }

    private void openPicker() {
        new AlertDialog.Builder(this).setTitle("اختر مصدر الفيديو")
            .setItems(new String[]{"معرض الصور والفيديو","مدير الملفات"},(d,which)->{
                Intent i;
                if(which==0){i=new Intent(Intent.ACTION_PICK,MediaStore.Video.Media.EXTERNAL_CONTENT_URI);i.setType("video/*");}
                else{i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("video/*");i.addCategory(Intent.CATEGORY_OPENABLE);}
                startActivityForResult(i,PICK_VIDEO);
            }).show();
    }

    private void openMergePicker() {
        new AlertDialog.Builder(this).setTitle("اختر مصدر الفيديوهات")
            .setItems(new String[]{"معرض الصور والفيديو","مدير الملفات"},(d,which)->{
                Intent i;
                if(which==0){i=new Intent(Intent.ACTION_PICK,MediaStore.Video.Media.EXTERNAL_CONTENT_URI);i.setType("video/*");}
                else{i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("video/*");i.addCategory(Intent.CATEGORY_OPENABLE);}
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);startActivityForResult(i,PICK_MERGE);
            }).show();
    }

    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req,result,data); if(result!=RESULT_OK || data==null) return;
        if(req==PICK_VIDEO) {
            sourceUri=data.getData();
            try{getContentResolver().takePersistableUriPermission(sourceUri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            showEditor();
        } else if(req==SAVE_VIDEO) { Uri out=data.getData(); if(out!=null) trimTo(out,false); }
        else if(req==SAVE_DELETE) { Uri out=data.getData(); if(out!=null) trimTo(out,true); }
        else if(req==SAVE_AUDIO) { Uri out=data.getData(); if(out!=null) extractAudio(out); }
        else if(req==SAVE_IMAGE) { Uri out=data.getData(); if(out!=null) extractFrame(out); }
        else if(req==PICK_MERGE) {
            mergeUris.clear();
            if(data.getClipData()!=null) for(int n=0;n<data.getClipData().getItemCount();n++) mergeUris.add(data.getClipData().getItemAt(n).getUri());
            else if(data.getData()!=null) mergeUris.add(data.getData());
            if(mergeUris.size()<2) Toast.makeText(this,"اختر مقطعين على الأقل",Toast.LENGTH_LONG).show();
            else requestDocument("video/mp4","AI_Video_Pro_Merged_"+System.currentTimeMillis()+".mp4",SAVE_MERGE);
        } else if(req==SAVE_MERGE) { Uri out=data.getData(); if(out!=null) mergeVideos(out); }
    }

    private void showEditor() {
        base("قص الفيديو");
        videoView = new VideoView(this);
        videoView.setBackgroundColor(Color.BLACK);
        videoView.setVideoURI(sourceUri);
        videoView.requestFocus();
        FrameLayout preview=new FrameLayout(this);preview.setBackgroundColor(Color.BLACK);preview.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        FrameLayout.LayoutParams videoParams=new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER);preview.addView(videoView,videoParams);
        root.addView(preview,new LinearLayout.LayoutParams(-1,dp(280)));
        Button play=button("▶ تشغيل / إيقاف"); play.setOnClickListener(v->{ if(videoView.isPlaying()) videoView.pause(); else videoView.start(); }); root.addView(play);
        rangeLabel=text("جارٍ قراءة مدة الفيديو…",15,Color.WHITE); root.addView(rangeLabel);
        root.addView(text("اسحب المقبضين الأصفرين لتحديد المقطع",14,0xFFFFC84A));
        timeline=new TimelineView(this);root.addView(timeline,new LinearLayout.LayoutParams(-1,dp(125)));
        startBar=new SeekBar(this); startBar.setMax(1000);startBar.setVisibility(View.GONE);root.addView(startBar);
        endBar=new SeekBar(this); endBar.setMax(1000); endBar.setProgress(1000);endBar.setVisibility(View.GONE);root.addView(endBar);
        timeline.setListener((a,b,finished)->{if(finished)rememberRange();startBar.setProgress(a);endBar.setProgress(b);updateRange();if(finished)videoView.seekTo((int)(durationMs*a/1000));});
        SeekBar.OnSeekBarChangeListener listener=new SeekBar.OnSeekBarChangeListener(){ public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){ videoView.seekTo((int)(durationMs*s.getProgress()/1000)); } public void onProgressChanged(SeekBar s,int p,boolean u){ if(startBar.getProgress()>=endBar.getProgress()){ if(s==startBar) endBar.setProgress(Math.min(1000,p+1)); else startBar.setProgress(Math.max(0,p-1)); } updateRange(); }};
        startBar.setOnSeekBarChangeListener(listener); endBar.setOnSeekBarChangeListener(listener);
        videoView.setOnPreparedListener(mp->{
            durationMs=mp.getDuration();
            videoView.setBackgroundColor(Color.TRANSPARENT);
            videoView.seekTo(1);
            timeline.load(this,sourceUri,durationMs);
            undoRanges.clear();redoRanges.clear();undoRanges.add(new int[]{0,1000});
            updateRange();
        });
        videoView.setOnErrorListener((mp,what,extra)->{
            rangeLabel.setText("تعذر تشغيل هذا الفيديو. اختر فيديو MP4 مصورًا بكاميرا الهاتف.");
            Toast.makeText(this,"صيغة الفيديو غير مدعومة",Toast.LENGTH_LONG).show();
            return true;
        });
        root.addView(text("أدوات التحرير — اسحب أفقيًا",16,Color.WHITE));
        muteBox=new CheckBox(this);muteBox.setVisibility(View.GONE);
        speedSpinner=new Spinner(this);speedSpinner.setAdapter(darkSpinnerAdapter(new String[]{"0.5×","1×","1.5×","2×"}));speedSpinner.setSelection(1);
        rotateSpinner=new Spinner(this);rotateSpinner.setAdapter(darkSpinnerAdapter(new String[]{"بدون تدوير","90°","180°","270°"}));
        HorizontalScrollView toolsScroll=new HorizontalScrollView(this);toolsScroll.setHorizontalScrollBarEnabled(false);toolsScroll.setFillViewport(false);toolsScroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout toolsRow=new LinearLayout(this);toolsRow.setOrientation(LinearLayout.HORIZONTAL);toolsRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);toolsScroll.addView(toolsRow);
        Button undo=toolButton("↶\nتراجع");undo.setOnClickListener(v->undoRange());toolsRow.addView(undo);
        Button redo=toolButton("↷\nإعادة");redo.setOnClickListener(v->redoRange());toolsRow.addView(redo);
        Button mute=toolButton("🔊\nكتم الصوت");mute.setOnClickListener(v->{muteBox.setChecked(!muteBox.isChecked());mute.setText(muteBox.isChecked()?"🔇\nالصوت مكتوم":"🔊\nكتم الصوت");});toolsRow.addView(mute);
        Button speed=toolButton("⏱\nالسرعة 1×");speed.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("سرعة الفيديو").setSingleChoiceItems(new String[]{"0.5×","1×","1.5×","2×"},speedSpinner.getSelectedItemPosition(),(d,w)->{speedSpinner.setSelection(w);speed.setText("⏱\nالسرعة "+new String[]{"0.5×","1×","1.5×","2×"}[w]);d.dismiss();}).show());toolsRow.addView(speed);
        Button rotate=toolButton("↻\nتدوير");rotate.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("تدوير الفيديو").setSingleChoiceItems(new String[]{"بدون تدوير","90°","180°","270°"},rotateSpinner.getSelectedItemPosition(),(d,w)->{rotateSpinner.setSelection(w);rotate.setText("↻\n"+new String[]{"بدون تدوير","90°","180°","270°"}[w]);d.dismiss();}).show());toolsRow.addView(rotate);
        Button save=toolButton("⬇\nحفظ الفيديو");save.setBackgroundColor(purple);save.setOnClickListener(v->chooseSave(false));toolsRow.addView(save);
        Button delete=toolButton("✂\nحذف المحدد");delete.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف الجزء المحدد").setMessage("سيتم إنشاء فيديو جديد بدون الجزء الواقع بين المقبضين الأصفرين.").setNegativeButton("إلغاء",null).setPositiveButton("متابعة",(d,w)->chooseSave(true)).show());toolsRow.addView(delete);
        Button audio=toolButton("♫\nاستخراج الصوت");audio.setOnClickListener(v->requestDocument("audio/mp4","AI_Video_Pro_Audio_"+System.currentTimeMillis()+".m4a",SAVE_AUDIO));toolsRow.addView(audio);
        Button image=toolButton("▣\nاستخراج صورة");image.setOnClickListener(v->requestDocument("image/jpeg","AI_Video_Pro_Cover_"+System.currentTimeMillis()+".jpg",SAVE_IMAGE));toolsRow.addView(image);
        Button share=toolButton("↗\nمشاركة");share.setOnClickListener(v->shareLast());toolsRow.addView(share);
        root.addView(toolsScroll,new LinearLayout.LayoutParams(-1,dp(90)));
        status=text("",14,0xFFBFA9FF); root.addView(status);
        Button back=button("العودة للرئيسية"); back.setBackgroundColor(0xFF302843); back.setOnClickListener(v->showHome()); root.addView(back);
    }

    private void updateRange(){ if(rangeLabel==null||durationMs==0)return; long a=durationMs*startBar.getProgress()/1000,b=durationMs*endBar.getProgress()/1000; rangeLabel.setText("من "+time(a)+" إلى "+time(b)+" — المدة "+time(b-a)); }
    private String time(long ms){return String.format(Locale.US,"%02d:%02d",ms/60000,(ms/1000)%60);}
    private void chooseSave(boolean delete){
        new AlertDialog.Builder(this).setTitle("مكان حفظ الفيديو").setItems(new String[]{"حفظ مباشرة في معرض الصور","اختيار المجلد أو المكان"},(d,w)->{
            if(w==0)saveVideoToGallery(delete);else requestDocument("video/mp4","AI_Video_Pro_"+System.currentTimeMillis()+".mp4",delete?SAVE_DELETE:SAVE_VIDEO);
        }).show();
    }
    private void saveVideoToGallery(boolean delete){
        ContentValues values=new ContentValues();values.put(MediaStore.Video.Media.DISPLAY_NAME,"AI_Video_Pro_"+System.currentTimeMillis()+".mp4");values.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");
        if(Build.VERSION.SDK_INT>=29){values.put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/AI Video Pro");values.put(MediaStore.Video.Media.IS_PENDING,1);}
        Uri out=getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,values);
        if(out==null){Toast.makeText(this,"تعذر إنشاء الملف في المعرض",Toast.LENGTH_LONG).show();return;}
        trimTo(out,delete);
    }
    private void requestDocument(String type,String name,int request){ Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.setType(type); i.putExtra(Intent.EXTRA_TITLE,name); startActivityForResult(i,request); }

    private void trimTo(Uri output, boolean delete) {
        status.setText(delete?"جارٍ حذف الجزء المحدد…":"جارٍ تجهيز الفيديو… لا تغلق التطبيق");
        final long startUs=durationMs*startBar.getProgress()*1000/1000, endUs=durationMs*endBar.getProgress()*1000/1000;
        new Thread(()->{
            try(ParcelFileDescriptor inFd=getContentResolver().openFileDescriptor(sourceUri,"r"); ParcelFileDescriptor outFd=getContentResolver().openFileDescriptor(output,"rw")){
                MediaExtractor ex=new MediaExtractor(); ex.setDataSource(inFd.getFileDescriptor());
                MediaMuxer mux=new MediaMuxer(outFd.getFileDescriptor(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
                int rotation=rotateSpinner.getSelectedItemPosition()*90; if(rotation!=0)mux.setOrientationHint(rotation);
                float speed=new float[]{.5f,1f,1.5f,2f}[speedSpinner.getSelectedItemPosition()];
                int count=ex.getTrackCount(), max=1024*1024; int[] map=new int[count];
                for(int t=0;t<count;t++){MediaFormat f=ex.getTrackFormat(t); String mime=f.getString(MediaFormat.KEY_MIME); if(muteBox.isChecked()&&mime!=null&&mime.startsWith("audio/")){map[t]=-1;continue;} map[t]=mux.addTrack(f); if(f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) max=Math.max(max,f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)); ex.selectTrack(t);}
                mux.start(); ByteBuffer buf=ByteBuffer.allocate(max); MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
                long[][] ranges=delete?new long[][]{{0,startUs},{endUs,durationMs*1000L}}:new long[][]{{startUs,endUs}};long outputOffset=0;
                for(long[] range:ranges){if(range[1]-range[0]<1000)continue;ex.seekTo(range[0],MediaExtractor.SEEK_TO_PREVIOUS_SYNC);long first=-1,last=0;while(true){info.offset=0;info.size=ex.readSampleData(buf,0);long sample=ex.getSampleTime();if(info.size<0||sample>range[1])break;int track=ex.getSampleTrackIndex();if(sample>=range[0]&&map[track]>=0){if(first<0)first=sample;info.presentationTimeUs=outputOffset+(long)((sample-first)/speed);info.flags=ex.getSampleFlags();mux.writeSampleData(map[track],buf,info);last=info.presentationTimeUs;}ex.advance();}outputOffset=last+33333;}
                mux.stop(); mux.release(); ex.release();
                if(Build.VERSION.SDK_INT>=29)try{ContentValues done=new ContentValues();done.put(MediaStore.Video.Media.IS_PENDING,0);getContentResolver().update(output,done,null,null);}catch(Exception ignored){}
                lastSavedUri=output; runOnUiThread(()->{status.setText("تم الحفظ بنجاح ✓"); new AlertDialog.Builder(this).setTitle("اكتمل").setMessage("تم إنشاء الفيديو وحفظه بنجاح. يمكنك فتحه من معرض الصور.").setPositiveButton("حسنًا",null).show();});
            }catch(Exception e){runOnUiThread(()->status.setText("تعذر القص: "+e.getMessage()));}
        }).start();
    }

    private void rememberRange(){int a=startBar.getProgress(),b=endBar.getProgress();if(undoRanges.isEmpty()||undoRanges.get(undoRanges.size()-1)[0]!=a||undoRanges.get(undoRanges.size()-1)[1]!=b)undoRanges.add(new int[]{a,b});redoRanges.clear();}
    private void applyRange(int[] r){startBar.setProgress(r[0]);endBar.setProgress(r[1]);timeline.setRange(r[0],r[1]);updateRange();videoView.seekTo((int)(durationMs*r[0]/1000));}
    private void undoRange(){if(undoRanges.size()<2){Toast.makeText(this,"لا يوجد تعديل سابق",Toast.LENGTH_SHORT).show();return;}redoRanges.add(undoRanges.remove(undoRanges.size()-1));applyRange(undoRanges.get(undoRanges.size()-1));}
    private void redoRange(){if(redoRanges.isEmpty()){Toast.makeText(this,"لا يوجد تعديل لإعادته",Toast.LENGTH_SHORT).show();return;}int[] r=redoRanges.remove(redoRanges.size()-1);undoRanges.add(r);applyRange(r);}

    private void extractAudio(Uri output){
        status.setText("جارٍ استخراج الصوت…");
        new Thread(()->{
            try(ParcelFileDescriptor inFd=getContentResolver().openFileDescriptor(sourceUri,"r"); ParcelFileDescriptor outFd=getContentResolver().openFileDescriptor(output,"rw")){
                MediaExtractor ex=new MediaExtractor(); ex.setDataSource(inFd.getFileDescriptor()); int audioTrack=-1;
                for(int t=0;t<ex.getTrackCount();t++){String mime=ex.getTrackFormat(t).getString(MediaFormat.KEY_MIME); if(mime!=null&&mime.startsWith("audio/")){audioTrack=t;break;}}
                if(audioTrack<0)throw new IOException("الفيديو لا يحتوي على صوت");
                MediaFormat format=ex.getTrackFormat(audioTrack); ex.selectTrack(audioTrack);
                MediaMuxer mux=new MediaMuxer(outFd.getFileDescriptor(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4); int outTrack=mux.addTrack(format); mux.start();
                ByteBuffer buf=ByteBuffer.allocate(format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)?Math.max(1024*1024,format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)):1024*1024); MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
                while(true){info.offset=0;info.size=ex.readSampleData(buf,0);if(info.size<0)break;info.presentationTimeUs=ex.getSampleTime();info.flags=ex.getSampleFlags();mux.writeSampleData(outTrack,buf,info);ex.advance();}
                mux.stop();mux.release();ex.release();lastSavedUri=output;runOnUiThread(()->status.setText("تم استخراج الصوت بنجاح ✓"));
            }catch(Exception e){runOnUiThread(()->status.setText("تعذر استخراج الصوت: "+e.getMessage()));}
        }).start();
    }

    private void extractFrame(Uri output){
        status.setText("جارٍ استخراج الصورة…");
        new Thread(()->{
            MediaMetadataRetriever r=new MediaMetadataRetriever();
            try(OutputStream os=getContentResolver().openOutputStream(output,"w")){
                r.setDataSource(this,sourceUri); long atUs=durationMs*startBar.getProgress(); android.graphics.Bitmap frame=r.getFrameAtTime(atUs,MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                if(frame==null)throw new IOException("تعذر قراءة الصورة"); frame.compress(android.graphics.Bitmap.CompressFormat.JPEG,92,os); frame.recycle(); lastSavedUri=output;
                runOnUiThread(()->status.setText("تم حفظ الصورة بنجاح ✓"));
            }catch(Exception e){runOnUiThread(()->status.setText("تعذر استخراج الصورة: "+e.getMessage()));}finally{try{r.release();}catch(Exception ignored){}}
        }).start();
    }

    private void shareLast(){
        if(lastSavedUri==null){Toast.makeText(this,"احفظ نتيجة أولًا ثم شاركها",Toast.LENGTH_LONG).show();return;}
        Intent i=new Intent(Intent.ACTION_SEND);i.setType("video/*");i.putExtra(Intent.EXTRA_STREAM,lastSavedUri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"مشاركة النتيجة"));
    }

    private void mergeVideos(Uri output){
        Toast.makeText(this,"جارٍ دمج المقاطع…",Toast.LENGTH_LONG).show();
        new Thread(()->{
            MediaMuxer mux=null;
            try(ParcelFileDescriptor outFd=getContentResolver().openFileDescriptor(output,"rw")){
                mux=new MediaMuxer(outFd.getFileDescriptor(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
                ArrayList<String> outMimes=new ArrayList<>(); ArrayList<Integer> outTracks=new ArrayList<>();
                try(ParcelFileDescriptor firstFd=getContentResolver().openFileDescriptor(mergeUris.get(0),"r")){
                    MediaExtractor first=new MediaExtractor();first.setDataSource(firstFd.getFileDescriptor());
                    for(int t=0;t<first.getTrackCount();t++){MediaFormat f=first.getTrackFormat(t);String mime=f.getString(MediaFormat.KEY_MIME);if(mime!=null&&(mime.startsWith("video/")||mime.startsWith("audio/"))){outMimes.add(mime);outTracks.add(mux.addTrack(f));}}
                    first.release();
                }
                mux.start(); long offsetUs=0; ByteBuffer buf=ByteBuffer.allocate(4*1024*1024); MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
                for(Uri uri:mergeUris){long clipMax=0;try(ParcelFileDescriptor fd=getContentResolver().openFileDescriptor(uri,"r")){
                    MediaExtractor ex=new MediaExtractor();ex.setDataSource(fd.getFileDescriptor());int[] map=new int[ex.getTrackCount()];java.util.Arrays.fill(map,-1);
                    for(int t=0;t<ex.getTrackCount();t++){String mime=ex.getTrackFormat(t).getString(MediaFormat.KEY_MIME);for(int m=0;m<outMimes.size();m++)if(outMimes.get(m).equals(mime)){map[t]=outTracks.get(m);ex.selectTrack(t);break;}}
                    while(true){info.offset=0;info.size=ex.readSampleData(buf,0);if(info.size<0)break;int track=ex.getSampleTrackIndex();long sample=ex.getSampleTime();clipMax=Math.max(clipMax,sample);if(track>=0&&map[track]>=0){info.presentationTimeUs=offsetUs+sample;info.flags=ex.getSampleFlags();mux.writeSampleData(map[track],buf,info);}ex.advance();}ex.release();
                }offsetUs+=clipMax+33333;}
                mux.stop();mux.release();mux=null;lastSavedUri=output;runOnUiThread(()->new AlertDialog.Builder(this).setTitle("اكتمل").setMessage("تم دمج الفيديوهات وحفظ النتيجة.").setPositiveButton("حسنًا",null).show());
            }catch(Exception e){if(mux!=null)try{mux.release();}catch(Exception ignored){}runOnUiThread(()->Toast.makeText(this,"تعذر الدمج: يجب أن تكون المقاطع بنفس الدقة والصيغة",Toast.LENGTH_LONG).show());}
        }).start();
    }

    private void showAi(){
        base("توليد فيديو AI");
        root.addView(text("هذه الميزة تحتاج خادمًا آمنًا ومفتاح مزود التوليد. لن نضع المفتاح داخل التطبيق حتى لا تتم سرقته.",17,0xFFE8E3F3));
        EditText prompt=new EditText(this); prompt.setHint("مثال: سيارة رياضية تسير في شوارع الرياض ليلًا"); prompt.setTextColor(Color.WHITE); prompt.setHintTextColor(0xFF8F879E); prompt.setGravity(Gravity.RIGHT); root.addView(prompt,new LinearLayout.LayoutParams(-1,dp(120)));
        Button locked=button("قيد ربط خادم التوليد الآمن"); locked.setEnabled(false); locked.setAlpha(.55f); root.addView(locked);
        root.addView(text("سيُفعّل الزر بعد اختبار التكلفة والنتائج، ثم يحصل أول 30 مستخدمًا على فيديو تجريبي واحد.",14,0xFFBFA9FF));
        Button back=button("العودة للرئيسية"); back.setBackgroundColor(0xFF302843); back.setOnClickListener(v->showHome()); root.addView(back);
    }

    @Override public void onBackPressed(){ showHome(); }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
}
