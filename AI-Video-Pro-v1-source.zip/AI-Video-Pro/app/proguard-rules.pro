# Version 1 keeps shrinking disabled while core media tools are tested.
