plugins { id("com.android.application") }

android {
    namespace = "com.smartdailytools.aivideopro"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.smartdailytools.aivideopro"
        minSdk = 26
        targetSdk = 35
        versionCode = 5
        versionName = "3.1.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
