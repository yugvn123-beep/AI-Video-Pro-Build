plugins { id("com.android.application") }

android {
    namespace = "com.smartdailytools.aivideopro"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.smartdailytools.aivideopro"
        minSdk = 26
        targetSdk = 35
        versionCode = 12
        versionName = "4.3.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}

dependencies {
    implementation("androidx.media3:media3-transformer:1.8.0")
    implementation("androidx.media3:media3-effect:1.8.0")
    implementation("androidx.media3:media3-common:1.8.0")
}
