plugins { id("com.android.application") }

android {
    namespace = "com.smartdailytools.aivideopro"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.smartdailytools.aivideopro"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "3.0.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
}
