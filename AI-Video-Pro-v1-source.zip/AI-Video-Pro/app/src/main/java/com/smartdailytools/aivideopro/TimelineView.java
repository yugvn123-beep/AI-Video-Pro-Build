package com.smartdailytools.aivideopro;

import android.content.Context;
import android.graphics.*;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;

public class TimelineView extends View {
    public interface Listener { void onRangeChanged(int start, int end, boolean finished); }
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ArrayList<Bitmap> frames=new ArrayList<>();
    private Listener listener; private int start=0,end=1000,drag=0; private float density;
    public TimelineView(Context c){super(c);init();} public TimelineView(Context c, AttributeSet a){super(c,a);init();}
    private void init(){density=getResources().getDisplayMetrics().density;setMinimumHeight((int)(116*density));paint.setTypeface(Typeface.DEFAULT_BOLD);}
    public void setListener(Listener l){listener=l;}
    public int getStart(){return start;} public int getEnd(){return end;}
    public void load(Context context, Uri uri, long durationMs){
        new Thread(()->{MediaMetadataRetriever r=new MediaMetadataRetriever();ArrayList<Bitmap> loaded=new ArrayList<>();
            try{r.setDataSource(context,uri);for(int i=0;i<8;i++){Bitmap b=r.getFrameAtTime(durationMs*1000L*i/7,MediaMetadataRetriever.OPTION_CLOSEST_SYNC);if(b!=null)loaded.add(b);}}
            catch(Exception ignored){}finally{try{r.release();}catch(Exception ignored){}}
            post(()->{for(Bitmap b:frames)b.recycle();frames.clear();frames.addAll(loaded);invalidate();});
        }).start();
    }
    @Override protected void onDraw(Canvas c){super.onDraw(c);float top=24*density,bottom=getHeight()-18*density,w=getWidth();
        paint.setColor(Color.rgb(28,25,36));c.drawRoundRect(0,top,w,bottom,10*density,10*density,paint);
        if(frames.isEmpty()){paint.setColor(Color.DKGRAY);c.drawRect(0,top,w,bottom,paint);}else{float cell=w/frames.size();for(int i=0;i<frames.size();i++){Bitmap b=frames.get(i);Rect src=centerCrop(b,(int)cell,(int)(bottom-top));RectF dst=new RectF(i*cell,top,(i+1)*cell+1,bottom);c.drawBitmap(b,src,dst,paint);}}
        float sx=w*start/1000f,ex=w*end/1000f;paint.setColor(0x99000000);c.drawRect(0,top,sx,bottom,paint);c.drawRect(ex,top,w,bottom,paint);
        paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(4*density);paint.setColor(0xFFFFB300);c.drawRect(sx,top,ex,bottom,paint);paint.setStyle(Paint.Style.FILL);
        c.drawRoundRect(sx-9*density,top-7*density,sx+9*density,bottom+7*density,8*density,8*density,paint);c.drawRoundRect(ex-9*density,top-7*density,ex+9*density,bottom+7*density,8*density,8*density,paint);
        paint.setColor(Color.WHITE);paint.setStrokeWidth(2*density);c.drawLine(sx,top+18*density,sx,bottom-18*density,paint);c.drawLine(ex,top+18*density,ex,bottom-18*density,paint);
    }
    private Rect centerCrop(Bitmap b,int dw,int dh){float sr=(float)b.getWidth()/b.getHeight(),dr=(float)dw/dh;int sw=b.getWidth(),sh=b.getHeight();if(sr>dr){sw=(int)(sh*dr);}else{sh=(int)(sw/dr);}int l=(b.getWidth()-sw)/2,t=(b.getHeight()-sh)/2;return new Rect(l,t,l+sw,t+sh);}
    @Override public boolean onTouchEvent(MotionEvent e){float x=Math.max(0,Math.min(getWidth(),e.getX()));int p=(int)(1000*x/getWidth());if(e.getAction()==MotionEvent.ACTION_DOWN){float sx=getWidth()*start/1000f,ex=getWidth()*end/1000f;drag=Math.abs(x-sx)<=Math.abs(x-ex)?1:2;getParent().requestDisallowInterceptTouchEvent(true);return true;}if(e.getAction()==MotionEvent.ACTION_MOVE||e.getAction()==MotionEvent.ACTION_UP){if(drag==1)start=Math.min(end-10,p);else end=Math.max(start+10,p);start=Math.max(0,start);end=Math.min(1000,end);invalidate();if(listener!=null)listener.onRangeChanged(start,end,e.getAction()==MotionEvent.ACTION_UP);if(e.getAction()==MotionEvent.ACTION_UP){drag=0;getParent().requestDisallowInterceptTouchEvent(false);}return true;}return super.onTouchEvent(e);}
}
