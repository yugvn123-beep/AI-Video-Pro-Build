package com.smartdailytools.aivideopro;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.media.*;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.graphics.Typeface;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Effect;
import androidx.media3.common.MimeTypes;
import androidx.media3.effect.OverlayEffect;
import androidx.media3.effect.Presentation;
import androidx.media3.effect.ScaleAndRotateTransformation;
import androidx.media3.effect.StaticOverlaySettings;
import androidx.media3.effect.TextOverlay;
import androidx.media3.transformer.Composition;
import androidx.media3.transformer.EditedMediaItem;
import androidx.media3.transformer.EditedMediaItemSequence;
import androidx.media3.transformer.Effects;
import androidx.media3.transformer.ExportException;
import androidx.media3.transformer.ExportResult;
import androidx.media3.transformer.Transformer;
import com.google.common.collect.ImmutableList;
import java.io.*;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_VIDEO = 10, SAVE_VIDEO = 11, SAVE_AUDIO = 12, SAVE_IMAGE = 13, PICK_MERGE = 14, SAVE_MERGE = 15, SAVE_DELETE = 16, PICK_MUSIC = 17;
    private final int purple = Color.rgb(124,58,237), ink = Color.rgb(15,11,31);
    private LinearLayout root, editorBox;
    private VideoView videoView;
    private SeekBar startBar, endBar;
    private TimelineView timeline;
    private TextView rangeLabel, status;
    private Uri sourceUri;
    private long durationMs;
    private CheckBox muteBox;
    private Spinner speedSpinner, rotateSpinner, aspectSpinner, qualitySpinner;
    private String overlayText="";
    private int overlayColor=Color.WHITE,overlaySize=1,overlayPosition=2,backgroundMode=0;
    private int sourceVideoWidth=0,sourceVideoHeight=0,sourceRotationDegrees=0;
    private Uri musicUri;
    private Button musicToolButton;
    private final ArrayList<Uri> mergeUris = new ArrayList<>();
    private Uri lastSavedUri;
    private final ArrayList<int[]> undoRanges=new ArrayList<>(), redoRanges=new ArrayList<>();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(ink);
        showHome();
    }

    private TextView text(String value, int sp, int color) {
        TextView v = new TextView(this); v.setText(value); v.setTextSize(sp); v.setTextColor(color);
        v.setGravity(Gravity.RIGHT); v.setPadding(12,10,12,10); return v;
    }

    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextSize(16); b.setTextColor(Color.WHITE);
        b.setBackgroundColor(purple); b.setAllCaps(false); b.setPadding(16,8,16,8);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(54)); p.setMargins(0,8,0,8); b.setLayoutParams(p); return b;
    }

    private Button toolButton(String label){
        Button b=new Button(this);b.setText(label);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setAllCaps(false);b.setGravity(Gravity.CENTER);
        b.setBackgroundColor(0xFF302843);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(112),dp(76));p.setMargins(dp(5),dp(6),dp(5),dp(6));b.setLayoutParams(p);return b;
    }

    private ArrayAdapter<String> darkSpinnerAdapter(String[] values){
        return new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,values){
            private TextView style(TextView v){v.setTextColor(Color.WHITE);v.setTextSize(16);v.setPadding(dp(16),dp(12),dp(16),dp(12));v.setBackgroundColor(0xFF302843);return v;}
            @Override public View getView(int p,View c,android.view.ViewGroup parent){return style((TextView)super.getView(p,c,parent));}
            @Override public View getDropDownView(int p,View c,android.view.ViewGroup parent){return style((TextView)super.getDropDownView(p,c,parent));}
        };
    }

    private void base(String title) {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(ink);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20),dp(22),dp(20),dp(30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); scroll.addView(root);
        TextView logo = text("✦  AI VIDEO PRO",22,Color.WHITE); logo.setTypeface(null,1); root.addView(logo);
        TextView h = text(title,28,Color.WHITE); h.setTypeface(null,1); h.setPadding(12,22,12,8); root.addView(h);
        setContentView(scroll);
    }

    private void showHome() {
        base("أنشئ فيديوك باحتراف");
        root.addView(text("مونتاج سريع وأدوات ذكاء اصطناعي مصممة للمحتوى العربي.",16,0xFFCCC6DD));
        HorizontalScrollView homeScroll=new HorizontalScrollView(this);homeScroll.setHorizontalScrollBarEnabled(false);homeScroll.setFillViewport(false);homeScroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout homeRow=new LinearLayout(this);homeRow.setOrientation(LinearLayout.HORIZONTAL);homeRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);homeScroll.addView(homeRow);
        Button edit=toolButton("🎬\nقص فيديو");edit.setBackgroundColor(purple);edit.setOnClickListener(v->openPicker());homeRow.addView(edit);
        Button merge=toolButton("🎞\nدمج فيديوهات");merge.setBackgroundColor(purple);merge.setOnClickListener(v->openMergePicker());homeRow.addView(merge);
        Button ai=toolButton("✨\nتوليد فيديو AI");ai.setBackgroundColor(purple);ai.setOnClickListener(v->showAi());homeRow.addView(ai);
        root.addView(homeScroll,new LinearLayout.LayoutParams(-1,dp(92)));
        root.addView(text("أدوات الإصدار "+installedVersion(),19,Color.WHITE));
        root.addView(text("✓ خط زمني مصوّر وقص دقيق\n✓ نص عربي وموسيقى خلفية\n✓ مقاسات 9:16 و1:1 و16:9\n✓ تصدير 480p و720p و1080p\n✓ كتم وسرعة وتدوير ودمج\n✓ حفظ مباشر في المعرض ومشاركة\n✓ معالجة محلية دون رفع ملفاتك",16,0xFFE8E3F3));
        status = text("الرصيد التجريبي: فيديو AI واحد بعد تفعيل الخادم",14,0xFFBFA9FF); root.addView(status);
    }

    private void openPicker() {
        new AlertDialog.Builder(this).setTitle("اختر مصدر الفيديو")
            .setItems(new String[]{"معرض الصور والفيديو","مدير الملفات"},(d,which)->{
                Intent i;
                if(which==0){i=new Intent(Intent.ACTION_PICK,MediaStore.Video.Media.EXTERNAL_CONTENT_URI);i.setType("video/*");}
                else{i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("video/*");i.addCategory(Intent.CATEGORY_OPENABLE);}
                startActivityForResult(i,PICK_VIDEO);
            }).show();
    }

    private void openMergePicker() {
        new AlertDialog.Builder(this).setTitle("اختر مصدر الفيديوهات")
            .setItems(new String[]{"معرض الصور والفيديو","مدير الملفات"},(d,which)->{
                Intent i;
                if(which==0){i=new Intent(Intent.ACTION_PICK,MediaStore.Video.Media.EXTERNAL_CONTENT_URI);i.setType("video/*");}
                else{i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("video/*");i.addCategory(Intent.CATEGORY_OPENABLE);}
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);startActivityForResult(i,PICK_MERGE);
            }).show();
    }

    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req,result,data); if(result!=RESULT_OK || data==null) return;
        if(req==PICK_VIDEO) {
            sourceUri=data.getData();
            try{getContentResolver().takePersistableUriPermission(sourceUri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            showEditor();
        } else if(req==PICK_MUSIC){musicUri=data.getData();try{getContentResolver().takePersistableUriPermission(musicUri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}if(musicToolButton!=null)musicToolButton.setText("♫✓\nتمت إضافة موسيقى");}
        else if(req==SAVE_VIDEO) { Uri out=data.getData(); if(out!=null) exportTo(out,false); }
        else if(req==SAVE_DELETE) { Uri out=data.getData(); if(out!=null) exportTo(out,true); }
        else if(req==SAVE_AUDIO) { Uri out=data.getData(); if(out!=null) extractAudio(out); }
        else if(req==SAVE_IMAGE) { Uri out=data.getData(); if(out!=null) extractFrame(out); }
        else if(req==PICK_MERGE) {
            mergeUris.clear();
            if(data.getClipData()!=null) for(int n=0;n<data.getClipData().getItemCount();n++) mergeUris.add(data.getClipData().getItemAt(n).getUri());
            else if(data.getData()!=null) mergeUris.add(data.getData());
            if(mergeUris.size()<2) Toast.makeText(this,"اختر مقطعين على الأقل",Toast.LENGTH_LONG).show();
            else requestDocument("video/mp4","AI_Video_Pro_Merged_"+System.currentTimeMillis()+".mp4",SAVE_MERGE);
        } else if(req==SAVE_MERGE) { Uri out=data.getData(); if(out!=null) mergeVideos(out); }
    }

    private void showEditor() {
        base("");
        root.removeViewAt(root.getChildCount()-1);
        LinearLayout topBar=new LinearLayout(this);topBar.setGravity(Gravity.CENTER_VERTICAL);topBar.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        Button close=toolButton("✕");close.setTextSize(22);close.setLayoutParams(new LinearLayout.LayoutParams(dp(56),dp(52)));close.setBackgroundColor(Color.TRANSPARENT);close.setOnClickListener(v->showHome());topBar.addView(close);
        TextView editorTitle=text("محرر الفيديو",20,Color.WHITE);editorTitle.setGravity(Gravity.CENTER);editorTitle.setTypeface(null,Typeface.BOLD);topBar.addView(editorTitle,new LinearLayout.LayoutParams(0,dp(52),1));
        Button exportTop=toolButton("تصدير");exportTop.setTextSize(15);exportTop.setBackgroundColor(purple);exportTop.setLayoutParams(new LinearLayout.LayoutParams(dp(92),dp(48)));exportTop.setOnClickListener(v->chooseSave(false));topBar.addView(exportTop);
        root.addView(topBar,new LinearLayout.LayoutParams(-1,dp(58)));
        videoView = new VideoView(this);
        videoView.setBackgroundColor(Color.BLACK);
        videoView.setVideoURI(sourceUri);
        videoView.requestFocus();
        FrameLayout preview=new FrameLayout(this);preview.setBackgroundColor(Color.BLACK);preview.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        FrameLayout.LayoutParams videoParams=new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER);preview.addView(videoView,videoParams);
        root.addView(preview,new LinearLayout.LayoutParams(-1,dp(350)));
        LinearLayout playback=new LinearLayout(this);playback.setGravity(Gravity.CENTER);playback.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        Button undoTop=toolButton("↶");undoTop.setTextSize(22);undoTop.setLayoutParams(new LinearLayout.LayoutParams(dp(64),dp(54)));undoTop.setOnClickListener(v->undoRange());playback.addView(undoTop);
        Button play=toolButton("▶");play.setTextSize(24);play.setBackgroundColor(Color.TRANSPARENT);play.setLayoutParams(new LinearLayout.LayoutParams(0,dp(58),1));play.setOnClickListener(v->{if(videoView.isPlaying()){videoView.pause();play.setText("▶");}else{videoView.start();play.setText("Ⅱ");}});playback.addView(play);
        Button redoTop=toolButton("↷");redoTop.setTextSize(22);redoTop.setLayoutParams(new LinearLayout.LayoutParams(dp(64),dp(54)));redoTop.setOnClickListener(v->redoRange());playback.addView(redoTop);
        root.addView(playback,new LinearLayout.LayoutParams(-1,dp(60)));
        rangeLabel=text("جارٍ قراءة مدة الفيديو…",15,Color.WHITE); root.addView(rangeLabel);
        root.addView(text("اسحب المقبضين الأصفرين لتحديد المقطع",14,0xFFFFC84A));
        timeline=new TimelineView(this);root.addView(timeline,new LinearLayout.LayoutParams(-1,dp(125)));
        startBar=new SeekBar(this); startBar.setMax(1000);startBar.setVisibility(View.GONE);root.addView(startBar);
        endBar=new SeekBar(this); endBar.setMax(1000); endBar.setProgress(1000);endBar.setVisibility(View.GONE);root.addView(endBar);
        timeline.setListener((a,b,finished)->{if(finished)rememberRange();startBar.setProgress(a);endBar.setProgress(b);updateRange();if(finished)videoView.seekTo((int)(durationMs*a/1000));});
        SeekBar.OnSeekBarChangeListener listener=new SeekBar.OnSeekBarChangeListener(){ public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){ videoView.seekTo((int)(durationMs*s.getProgress()/1000)); } public void onProgressChanged(SeekBar s,int p,boolean u){ if(startBar.getProgress()>=endBar.getProgress()){ if(s==startBar) endBar.setProgress(Math.min(1000,p+1)); else startBar.setProgress(Math.max(0,p-1)); } updateRange(); }};
        startBar.setOnSeekBarChangeListener(listener); endBar.setOnSeekBarChangeListener(listener);
        videoView.setOnPreparedListener(mp->{
            durationMs=mp.getDuration();
            sourceVideoWidth=mp.getVideoWidth();sourceVideoHeight=mp.getVideoHeight();
            readSourceRotation();
            videoView.setBackgroundColor(Color.TRANSPARENT);
            videoView.seekTo(1);
            timeline.load(this,sourceUri,durationMs);
            undoRanges.clear();redoRanges.clear();undoRanges.add(new int[]{0,1000});
            updateRange();
        });
        videoView.setOnErrorListener((mp,what,extra)->{
            rangeLabel.setText("تعذر تشغيل هذا الفيديو. اختر فيديو MP4 مصورًا بكاميرا الهاتف.");
            Toast.makeText(this,"صيغة الفيديو غير مدعومة",Toast.LENGTH_LONG).show();
            return true;
        });
        TextView toolHint=text("أدوات التحرير  ‹  اسحب أفقيًا  ›",15,0xFFCFC7DC);toolHint.setGravity(Gravity.CENTER);root.addView(toolHint);
        muteBox=new CheckBox(this);muteBox.setVisibility(View.GONE);
        speedSpinner=new Spinner(this);speedSpinner.setAdapter(darkSpinnerAdapter(new String[]{"0.5×","1×","1.5×","2×"}));speedSpinner.setSelection(1);
        rotateSpinner=new Spinner(this);rotateSpinner.setAdapter(darkSpinnerAdapter(new String[]{"بدون تدوير","90°","180°","270°"}));
        aspectSpinner=new Spinner(this);aspectSpinner.setAdapter(darkSpinnerAdapter(new String[]{"المقاس الأصلي","عمودي 9:16","مربع 1:1","أفقي 16:9"}));
        qualitySpinner=new Spinner(this);qualitySpinner.setAdapter(darkSpinnerAdapter(new String[]{"الجودة الأصلية","480p","720p","1080p"}));
        HorizontalScrollView toolsScroll=new HorizontalScrollView(this);toolsScroll.setHorizontalScrollBarEnabled(false);toolsScroll.setFillViewport(false);toolsScroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout toolsRow=new LinearLayout(this);toolsRow.setOrientation(LinearLayout.HORIZONTAL);toolsRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);toolsScroll.addView(toolsRow);
        Button undo=toolButton("↶\nتراجع");undo.setOnClickListener(v->undoRange());toolsRow.addView(undo);
        Button redo=toolButton("↷\nإعادة");redo.setOnClickListener(v->redoRange());toolsRow.addView(redo);
        Button mute=toolButton("🔊\nكتم الصوت");mute.setOnClickListener(v->{muteBox.setChecked(!muteBox.isChecked());mute.setText(muteBox.isChecked()?"🔇\nالصوت مكتوم":"🔊\nكتم الصوت");});toolsRow.addView(mute);
        Button speed=toolButton("⏱\nالسرعة 1×");speed.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("سرعة الفيديو").setSingleChoiceItems(new String[]{"0.5×","1×","1.5×","2×"},speedSpinner.getSelectedItemPosition(),(d,w)->{speedSpinner.setSelection(w);speed.setText("⏱\nالسرعة "+new String[]{"0.5×","1×","1.5×","2×"}[w]);d.dismiss();}).show());toolsRow.addView(speed);
        Button rotate=toolButton("↻\nتدوير");rotate.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("تدوير الفيديو").setSingleChoiceItems(new String[]{"بدون تدوير","90°","180°","270°"},rotateSpinner.getSelectedItemPosition(),(d,w)->{rotateSpinner.setSelection(w);rotate.setText("↻\n"+new String[]{"بدون تدوير","90°","180°","270°"}[w]);d.dismiss();}).show());toolsRow.addView(rotate);
        Button textTool=toolButton("T\nنص عربي");textTool.setOnClickListener(v->showTextDialog(textTool));toolsRow.addView(textTool);
        Button background=toolButton("▧\nالخلفية");background.setOnClickListener(v->showBackgroundDialog(background));toolsRow.addView(background);
        musicToolButton=toolButton("♫\nإضافة موسيقى");musicToolButton.setOnClickListener(v->showMusicDialog());toolsRow.addView(musicToolButton);
        Button aspect=toolButton("▣\nالمقاس");aspect.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("نسبة أبعاد الفيديو").setSingleChoiceItems(new String[]{"المقاس الأصلي","عمودي 9:16","مربع 1:1","أفقي 16:9"},aspectSpinner.getSelectedItemPosition(),(d,w)->{aspectSpinner.setSelection(w);aspect.setText("▣\n"+new String[]{"أصلي","9:16","1:1","16:9"}[w]);d.dismiss();}).show());toolsRow.addView(aspect);
        Button quality=toolButton("HD\nالجودة");quality.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("جودة التصدير").setSingleChoiceItems(new String[]{"الجودة الأصلية","480p","720p","1080p"},qualitySpinner.getSelectedItemPosition(),(d,w)->{qualitySpinner.setSelection(w);quality.setText("HD\n"+new String[]{"أصلية","480p","720p","1080p"}[w]);d.dismiss();}).show());toolsRow.addView(quality);
        Button smart=toolButton("✨\nتعديل ذكي AI");smart.setOnClickListener(v->applySmartEdit(smart,aspect,quality));toolsRow.addView(smart);
        Button save=toolButton("⬇\nحفظ الفيديو");save.setBackgroundColor(purple);save.setOnClickListener(v->chooseSave(false));toolsRow.addView(save);
        Button delete=toolButton("✂\nحذف المحدد");delete.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف الجزء المحدد").setMessage("سيتم إنشاء فيديو جديد بدون الجزء الواقع بين المقبضين الأصفرين.").setNegativeButton("إلغاء",null).setPositiveButton("متابعة",(d,w)->chooseSave(true)).show());toolsRow.addView(delete);
        Button audio=toolButton("♫\nاستخراج الصوت");audio.setOnClickListener(v->requestDocument("audio/mp4","AI_Video_Pro_Audio_"+System.currentTimeMillis()+".m4a",SAVE_AUDIO));toolsRow.addView(audio);
        Button image=toolButton("▣\nاستخراج صورة");image.setOnClickListener(v->requestDocument("image/jpeg","AI_Video_Pro_Cover_"+System.currentTimeMillis()+".jpg",SAVE_IMAGE));toolsRow.addView(image);
        Button share=toolButton("↗\nمشاركة");share.setOnClickListener(v->shareLast());toolsRow.addView(share);
        Button previewResult=toolButton("▶\nمعاينة المعدّل");previewResult.setOnClickListener(v->showEditedPreview());toolsRow.addView(previewResult);
        root.addView(toolsScroll,new LinearLayout.LayoutParams(-1,dp(90)));
        LinearLayout categories=new LinearLayout(this);categories.setGravity(Gravity.CENTER);categories.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        String[] categoryNames={"✂\nتحرير","♫\nصوت","T\nنص","▧\nخلفية","✨\nAI"};
        for(String name:categoryNames){TextView c=text(name,13,Color.WHITE);c.setGravity(Gravity.CENTER);c.setBackgroundColor(0xFF211A31);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,dp(58),1);cp.setMargins(dp(2),dp(3),dp(2),dp(3));categories.addView(c,cp);}
        root.addView(categories,new LinearLayout.LayoutParams(-1,dp(64)));
        status=text("",14,0xFFBFA9FF); root.addView(status);
        Button back=button("العودة للرئيسية"); back.setBackgroundColor(0xFF302843); back.setOnClickListener(v->showHome()); root.addView(back);
    }

    private void readSourceRotation(){
        MediaMetadataRetriever r=new MediaMetadataRetriever();
        try{r.setDataSource(this,sourceUri);String value=r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION);sourceRotationDegrees=value==null?0:Integer.parseInt(value);}
        catch(Exception ignored){sourceRotationDegrees=0;}finally{try{r.release();}catch(Exception ignored){}}
        if(sourceRotationDegrees==90||sourceRotationDegrees==270){int t=sourceVideoWidth;sourceVideoWidth=sourceVideoHeight;sourceVideoHeight=t;}
    }

    private String installedVersion(){
        try{return getPackageManager().getPackageInfo(getPackageName(),0).versionName;}
        catch(Exception ignored){return "4.2.0";}
    }

    private void updateRange(){ if(rangeLabel==null||durationMs==0)return; long a=durationMs*startBar.getProgress()/1000,b=durationMs*endBar.getProgress()/1000; rangeLabel.setText("من "+time(a)+" إلى "+time(b)+" — المدة "+time(b-a)); }
    private String time(long ms){return String.format(Locale.US,"%02d:%02d",ms/60000,(ms/1000)%60);}
    private void chooseSave(boolean delete){
        new AlertDialog.Builder(this).setTitle("مكان حفظ الفيديو").setItems(new String[]{"حفظ مباشرة في معرض الصور","اختيار المجلد أو المكان"},(d,w)->{
            if(w==0)saveVideoToGallery(delete);else requestDocument("video/mp4","AI_Video_Pro_"+System.currentTimeMillis()+".mp4",delete?SAVE_DELETE:SAVE_VIDEO);
        }).show();
    }
    private void saveVideoToGallery(boolean delete){
        ContentValues values=new ContentValues();values.put(MediaStore.Video.Media.DISPLAY_NAME,"AI_Video_Pro_"+System.currentTimeMillis()+".mp4");values.put(MediaStore.Video.Media.MIME_TYPE,"video/mp4");
        if(Build.VERSION.SDK_INT>=29){values.put(MediaStore.Video.Media.RELATIVE_PATH,"Movies/AI Video Pro");values.put(MediaStore.Video.Media.IS_PENDING,1);}
        Uri out=getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,values);
        if(out==null){Toast.makeText(this,"تعذر إنشاء الملف في المعرض",Toast.LENGTH_LONG).show();return;}
        exportTo(out,delete);
    }
    private void requestDocument(String type,String name,int request){ Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.setType(type); i.putExtra(Intent.EXTRA_TITLE,name); startActivityForResult(i,request); }

    private void showTextDialog(Button button){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),0,dp(18),0);
        EditText input=new EditText(this);input.setText(overlayText);input.setHint("اكتب النص الذي سيظهر على الفيديو");input.setGravity(Gravity.RIGHT);input.setSingleLine(false);input.setMinLines(2);box.addView(input,new LinearLayout.LayoutParams(-1,-2));
        Spinner size=new Spinner(this);size.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"نص صغير","نص متوسط","نص كبير"}));size.setSelection(overlaySize);box.addView(size);
        Spinner position=new Spinner(this);position.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"أعلى الفيديو","منتصف الفيديو","أسفل الفيديو"}));position.setSelection(overlayPosition);box.addView(position);
        Spinner color=new Spinner(this);color.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"أبيض","أصفر","أسود"}));color.setSelection(overlayColor==Color.YELLOW?1:overlayColor==Color.BLACK?2:0);box.addView(color);
        new AlertDialog.Builder(this).setTitle("إضافة نص عربي").setView(box).setNegativeButton("إلغاء",null).setNeutralButton("حذف النص",(d,w)->{overlayText="";button.setText("T\nنص عربي");}).setPositiveButton("تطبيق",(d,w)->{overlayText=input.getText().toString().trim();overlaySize=size.getSelectedItemPosition();overlayPosition=position.getSelectedItemPosition();overlayColor=color.getSelectedItemPosition()==1?Color.YELLOW:color.getSelectedItemPosition()==2?Color.BLACK:Color.WHITE;button.setText(overlayText.isEmpty()?"T\nنص عربي":"T✓\nتمت إضافة النص");}).show();
    }

    private void showBackgroundDialog(Button button){
        String[] choices={"الخلفية الأصلية","ملاءمة الفيديو بخلفية سوداء","ملء الشاشة مع قص الحواف"};
        new AlertDialog.Builder(this).setTitle("تغيير خلفية الإطار").setSingleChoiceItems(choices,backgroundMode,(d,w)->{backgroundMode=w;button.setText(w==0?"▧\nالخلفية":w==1?"▧✓\nخلفية سوداء":"▧✓\nملء الشاشة");d.dismiss();}).setNegativeButton("إلغاء",null).show();
    }

    private void applySmartEdit(Button smart,Button aspect,Button quality){
        int target=(sourceVideoHeight>sourceVideoWidth)?1:3;aspectSpinner.setSelection(target);qualitySpinner.setSelection(2);backgroundMode=2;speedSpinner.setSelection(1);rotateSpinner.setSelection(0);
        aspect.setText(target==1?"▣\n9:16":"▣\n16:9");quality.setText("HD\n720p");smart.setText("✨✓\nتم التحسين");
        Toast.makeText(this,"تم اختيار المقاس والجودة والملء الأنسب تلقائيًا",Toast.LENGTH_LONG).show();
    }

    private void showEditedPreview(){
        if(lastSavedUri==null){Toast.makeText(this,"احفظ الفيديو أولًا ثم افتح المعاينة",Toast.LENGTH_LONG).show();return;}
        final VideoView preview=new VideoView(this);preview.setVideoURI(lastSavedUri);preview.setOnPreparedListener(mp->{mp.setLooping(true);preview.start();});
        FrameLayout holder=new FrameLayout(this);holder.setBackgroundColor(Color.BLACK);holder.setPadding(0,dp(8),0,dp(8));holder.addView(preview,new FrameLayout.LayoutParams(-1,dp(390),Gravity.CENTER));
        new AlertDialog.Builder(this).setTitle("معاينة الفيديو المعدّل").setView(holder).setPositiveButton("إغلاق",(d,w)->preview.stopPlayback()).setOnCancelListener(d->preview.stopPlayback()).show();
    }

    private String fittedOverlayText(String value){
        String clean=value.trim().replaceAll("\\s+"," ");if(clean.length()<=18)return clean;StringBuilder out=new StringBuilder();int line=0;
        for(String word:clean.split(" ")){if(line>0&&line+1+word.length()>18){out.append('\n');line=0;}else if(line>0){out.append(' ');line++;}out.append(word);line+=word.length();}return out.toString();
    }

    private void showMusicDialog(){
        new AlertDialog.Builder(this).setTitle("موسيقى الخلفية").setItems(new String[]{"اختيار ملف صوتي","إزالة الموسيقى"},(d,w)->{if(w==0){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("audio/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,PICK_MUSIC);}else{musicUri=null;if(musicToolButton!=null)musicToolButton.setText("♫\nإضافة موسيقى");}}).show();
    }

    private boolean needsProfessionalExport(){return !overlayText.isEmpty()||musicUri!=null||aspectSpinner.getSelectedItemPosition()>0||qualitySpinner.getSelectedItemPosition()>0;}
    private void exportTo(Uri output,boolean delete){if(!delete&&needsProfessionalExport())transformVideo(output);else trimTo(output,delete);}

    private void transformVideo(Uri output){
        status.setText("جارٍ التصدير الاحترافي… لا تغلق التطبيق");
        long start=durationMs*startBar.getProgress()/1000,end=durationMs*endBar.getProgress()/1000;
        MediaItem.ClippingConfiguration clip=new MediaItem.ClippingConfiguration.Builder().setStartPositionMs(start).setEndPositionMs(end).build();
        MediaItem item=new MediaItem.Builder().setUri(sourceUri).setClippingConfiguration(clip).build();
        ArrayList<Effect> videoEffects=new ArrayList<>();
        int rotation=(sourceRotationDegrees+rotateSpinner.getSelectedItemPosition()*90)%360;if(rotation!=0)videoEffects.add(new ScaleAndRotateTransformation.Builder().setRotationDegrees(rotation).build());
        int aspect=aspectSpinner.getSelectedItemPosition();if(aspect>0){float ratio=new float[]{0f,9f/16f,1f,16f/9f}[aspect];int layout=backgroundMode==1?Presentation.LAYOUT_SCALE_TO_FIT:Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP;videoEffects.add(Presentation.createForAspectRatio(ratio,layout));}
        int quality=qualitySpinner.getSelectedItemPosition();if(quality>0)videoEffects.add(Presentation.createForHeight(new int[]{0,480,720,1080}[quality]));
        if(!overlayText.isEmpty()){
            SpannableString s=new SpannableString(fittedOverlayText(overlayText));s.setSpan(new ForegroundColorSpan(overlayColor),0,s.length(),Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);s.setSpan(new RelativeSizeSpan(new float[]{0.55f,0.75f,1.0f}[overlaySize]),0,s.length(),Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);s.setSpan(new StyleSpan(Typeface.BOLD),0,s.length(),Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            float y=new float[]{0.72f,0f,-0.72f}[overlayPosition];StaticOverlaySettings settings=new StaticOverlaySettings.Builder().setOverlayFrameAnchor(0f,0f).setBackgroundFrameAnchor(0f,y).build();
            videoEffects.add(new OverlayEffect(ImmutableList.of(TextOverlay.createStaticTextOverlay(s,settings))));
        }
        Effects effects=new Effects(ImmutableList.of(),videoEffects);
        EditedMediaItem.Builder editedBuilder=new EditedMediaItem.Builder(item).setRemoveAudio(muteBox.isChecked()).setEffects(effects);
        EditedMediaItem edited=editedBuilder.build();
        float selectedSpeed=new float[]{.5f,1f,1.5f,2f}[speedSpinner.getSelectedItemPosition()];
        File temp=new File(getCacheDir(),"ai_video_pro_export_"+System.currentTimeMillis()+".mp4");
        Transformer transformer=new Transformer.Builder(this).setVideoMimeType(MimeTypes.VIDEO_H264).addListener(new Transformer.Listener(){
            @Override public void onCompleted(Composition composition,ExportResult result){if(selectedSpeed==1f)copyExport(temp,output);else copyExportWithSpeed(temp,output,selectedSpeed);}
            @Override public void onError(Composition composition,ExportResult result,ExportException exception){temp.delete();status.setText("تعذر التصدير: "+exception.getMessage());}
        }).build();
        if(musicUri==null)transformer.start(edited,temp.getAbsolutePath());
        else{
            EditedMediaItem music=new EditedMediaItem.Builder(MediaItem.fromUri(musicUri)).build();
            EditedMediaItemSequence videoSequence=new EditedMediaItemSequence.Builder(ImmutableList.of(edited)).build();
            EditedMediaItemSequence musicSequence=new EditedMediaItemSequence.Builder(ImmutableList.of(music)).setIsLooping(true).build();
            Composition composition=new Composition.Builder(ImmutableList.of(videoSequence,musicSequence)).build();
            transformer.start(composition,temp.getAbsolutePath());
        }
    }

    private void copyExport(File temp,Uri output){
        new Thread(()->{try(InputStream in=new FileInputStream(temp);OutputStream out=getContentResolver().openOutputStream(output,"w")){byte[] b=new byte[1024*1024];int n;while((n=in.read(b))>0)out.write(b,0,n);lastSavedUri=output;if(Build.VERSION.SDK_INT>=29)try{ContentValues done=new ContentValues();done.put(MediaStore.Video.Media.IS_PENDING,0);getContentResolver().update(output,done,null,null);}catch(Exception ignored){}runOnUiThread(()->{status.setText("تم التصدير الاحترافي بنجاح ✓");new AlertDialog.Builder(this).setTitle("اكتمل").setMessage("تم حفظ الفيديو بالنص والمقاس والجودة التي اخترتها.").setPositiveButton("حسنًا",null).show();});}catch(Exception e){runOnUiThread(()->status.setText("تعذر حفظ النتيجة: "+e.getMessage()));}finally{temp.delete();}}).start();
    }

    private void copyExportWithSpeed(File temp,Uri output,float speed){
        new Thread(()->{MediaExtractor ex=null;MediaMuxer mux=null;try(ParcelFileDescriptor outFd=getContentResolver().openFileDescriptor(output,"rw")){
            ex=new MediaExtractor();ex.setDataSource(temp.getAbsolutePath());mux=new MediaMuxer(outFd.getFileDescriptor(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            int count=ex.getTrackCount(),max=1024*1024;int[] map=new int[count];
            for(int t=0;t<count;t++){MediaFormat f=ex.getTrackFormat(t);map[t]=mux.addTrack(f);if(f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE))max=Math.max(max,f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE));ex.selectTrack(t);}
            mux.start();ByteBuffer buf=ByteBuffer.allocate(max);MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
            while(true){info.offset=0;info.size=ex.readSampleData(buf,0);if(info.size<0)break;int track=ex.getSampleTrackIndex();info.presentationTimeUs=(long)(ex.getSampleTime()/speed);info.flags=ex.getSampleFlags();mux.writeSampleData(map[track],buf,info);ex.advance();}
            mux.stop();mux.release();mux=null;ex.release();ex=null;lastSavedUri=output;
            if(Build.VERSION.SDK_INT>=29)try{ContentValues done=new ContentValues();done.put(MediaStore.Video.Media.IS_PENDING,0);getContentResolver().update(output,done,null,null);}catch(Exception ignored){}
            runOnUiThread(()->{status.setText("تم التصدير الاحترافي بالسرعة المختارة ✓");new AlertDialog.Builder(this).setTitle("اكتمل").setMessage("تم حفظ الفيديو بالنص والمقاس والجودة والسرعة التي اخترتها.").setPositiveButton("حسنًا",null).show();});
        }catch(Exception e){if(mux!=null)try{mux.release();}catch(Exception ignored){}if(ex!=null)try{ex.release();}catch(Exception ignored){}runOnUiThread(()->status.setText("تعذر حفظ النتيجة: "+e.getMessage()));}finally{temp.delete();}}).start();
    }

    private void trimTo(Uri output, boolean delete) {
        status.setText(delete?"جارٍ حذف الجزء المحدد…":"جارٍ تجهيز الفيديو… لا تغلق التطبيق");
        final long startUs=durationMs*startBar.getProgress()*1000/1000, endUs=durationMs*endBar.getProgress()*1000/1000;
        new Thread(()->{
            try(ParcelFileDescriptor inFd=getContentResolver().openFileDescriptor(sourceUri,"r"); ParcelFileDescriptor outFd=getContentResolver().openFileDescriptor(output,"rw")){
                MediaExtractor ex=new MediaExtractor(); ex.setDataSource(inFd.getFileDescriptor());
                MediaMuxer mux=new MediaMuxer(outFd.getFileDescriptor(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
                int rotation=rotateSpinner.getSelectedItemPosition()*90; if(rotation!=0)mux.setOrientationHint(rotation);
                float speed=new float[]{.5f,1f,1.5f,2f}[speedSpinner.getSelectedItemPosition()];
                int count=ex.getTrackCount(), max=1024*1024; int[] map=new int[count];
                for(int t=0;t<count;t++){MediaFormat f=ex.getTrackFormat(t); String mime=f.getString(MediaFormat.KEY_MIME); if(muteBox.isChecked()&&mime!=null&&mime.startsWith("audio/")){map[t]=-1;continue;} map[t]=mux.addTrack(f); if(f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) max=Math.max(max,f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)); ex.selectTrack(t);}
                mux.start(); ByteBuffer buf=ByteBuffer.allocate(max); MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
                long[][] ranges=delete?new long[][]{{0,startUs},{endUs,durationMs*1000L}}:new long[][]{{startUs,endUs}};long outputOffset=0;
                for(long[] range:ranges){if(range[1]-range[0]<1000)continue;ex.seekTo(range[0],MediaExtractor.SEEK_TO_PREVIOUS_SYNC);long first=-1,last=0;while(true){info.offset=0;info.size=ex.readSampleData(buf,0);long sample=ex.getSampleTime();if(info.size<0||sample>range[1])break;int track=ex.getSampleTrackIndex();if(sample>=range[0]&&map[track]>=0){if(first<0)first=sample;info.presentationTimeUs=outputOffset+(long)((sample-first)/speed);info.flags=ex.getSampleFlags();mux.writeSampleData(map[track],buf,info);last=info.presentationTimeUs;}ex.advance();}outputOffset=last+33333;}
                mux.stop(); mux.release(); ex.release();
                if(Build.VERSION.SDK_INT>=29)try{ContentValues done=new ContentValues();done.put(MediaStore.Video.Media.IS_PENDING,0);getContentResolver().update(output,done,null,null);}catch(Exception ignored){}
                lastSavedUri=output; runOnUiThread(()->{status.setText("تم الحفظ بنجاح ✓"); new AlertDialog.Builder(this).setTitle("اكتمل").setMessage("تم إنشاء الفيديو وحفظه بنجاح. يمكنك فتحه من معرض الصور.").setPositiveButton("حسنًا",null).show();});
            }catch(Exception e){runOnUiThread(()->status.setText("تعذر القص: "+e.getMessage()));}
        }).start();
    }

    private void rememberRange(){int a=startBar.getProgress(),b=endBar.getProgress();if(undoRanges.isEmpty()||undoRanges.get(undoRanges.size()-1)[0]!=a||undoRanges.get(undoRanges.size()-1)[1]!=b)undoRanges.add(new int[]{a,b});redoRanges.clear();}
    private void applyRange(int[] r){startBar.setProgress(r[0]);endBar.setProgress(r[1]);timeline.setRange(r[0],r[1]);updateRange();videoView.seekTo((int)(durationMs*r[0]/1000));}
    private void undoRange(){if(undoRanges.size()<2){Toast.makeText(this,"لا يوجد تعديل سابق",Toast.LENGTH_SHORT).show();return;}redoRanges.add(undoRanges.remove(undoRanges.size()-1));applyRange(undoRanges.get(undoRanges.size()-1));}
    private void redoRange(){if(redoRanges.isEmpty()){Toast.makeText(this,"لا يوجد تعديل لإعادته",Toast.LENGTH_SHORT).show();return;}int[] r=redoRanges.remove(redoRanges.size()-1);undoRanges.add(r);applyRange(r);}

    private void extractAudio(Uri output){
        status.setText("جارٍ استخراج الصوت…");
        new Thread(()->{
            try(ParcelFileDescriptor inFd=getContentResolver().openFileDescriptor(sourceUri,"r"); ParcelFileDescriptor outFd=getContentResolver().openFileDescriptor(output,"rw")){
                MediaExtractor ex=new MediaExtractor(); ex.setDataSource(inFd.getFileDescriptor()); int audioTrack=-1;
                for(int t=0;t<ex.getTrackCount();t++){String mime=ex.getTrackFormat(t).getString(MediaFormat.KEY_MIME); if(mime!=null&&mime.startsWith("audio/")){audioTrack=t;break;}}
                if(audioTrack<0)throw new IOException("الفيديو لا يحتوي على صوت");
                MediaFormat format=ex.getTrackFormat(audioTrack); ex.selectTrack(audioTrack);
                MediaMuxer mux=new MediaMuxer(outFd.getFileDescriptor(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4); int outTrack=mux.addTrack(format); mux.start();
                ByteBuffer buf=ByteBuffer.allocate(format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)?Math.max(1024*1024,format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)):1024*1024); MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
                while(true){info.offset=0;info.size=ex.readSampleData(buf,0);if(info.size<0)break;info.presentationTimeUs=ex.getSampleTime();info.flags=ex.getSampleFlags();mux.writeSampleData(outTrack,buf,info);ex.advance();}
                mux.stop();mux.release();ex.release();lastSavedUri=output;runOnUiThread(()->status.setText("تم استخراج الصوت بنجاح ✓"));
            }catch(Exception e){runOnUiThread(()->status.setText("تعذر استخراج الصوت: "+e.getMessage()));}
        }).start();
    }

    private void extractFrame(Uri output){
        status.setText("جارٍ استخراج الصورة…");
        new Thread(()->{
            MediaMetadataRetriever r=new MediaMetadataRetriever();
            try(OutputStream os=getContentResolver().openOutputStream(output,"w")){
                r.setDataSource(this,sourceUri); long atUs=durationMs*startBar.getProgress(); android.graphics.Bitmap frame=r.getFrameAtTime(atUs,MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                if(frame==null)throw new IOException("تعذر قراءة الصورة"); frame.compress(android.graphics.Bitmap.CompressFormat.JPEG,92,os); frame.recycle(); lastSavedUri=output;
                runOnUiThread(()->status.setText("تم حفظ الصورة بنجاح ✓"));
            }catch(Exception e){runOnUiThread(()->status.setText("تعذر استخراج الصورة: "+e.getMessage()));}finally{try{r.release();}catch(Exception ignored){}}
        }).start();
    }

    private void shareLast(){
        if(lastSavedUri==null){Toast.makeText(this,"احفظ نتيجة أولًا ثم شاركها",Toast.LENGTH_LONG).show();return;}
        Intent i=new Intent(Intent.ACTION_SEND);i.setType("video/*");i.putExtra(Intent.EXTRA_STREAM,lastSavedUri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"مشاركة النتيجة"));
    }

    private void mergeVideos(Uri output){
        Toast.makeText(this,"جارٍ دمج المقاطع…",Toast.LENGTH_LONG).show();
        new Thread(()->{
            MediaMuxer mux=null;
            try(ParcelFileDescriptor outFd=getContentResolver().openFileDescriptor(output,"rw")){
                mux=new MediaMuxer(outFd.getFileDescriptor(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
                ArrayList<String> outMimes=new ArrayList<>(); ArrayList<Integer> outTracks=new ArrayList<>();
                try(ParcelFileDescriptor firstFd=getContentResolver().openFileDescriptor(mergeUris.get(0),"r")){
                    MediaExtractor first=new MediaExtractor();first.setDataSource(firstFd.getFileDescriptor());
                    for(int t=0;t<first.getTrackCount();t++){MediaFormat f=first.getTrackFormat(t);String mime=f.getString(MediaFormat.KEY_MIME);if(mime!=null&&(mime.startsWith("video/")||mime.startsWith("audio/"))){outMimes.add(mime);outTracks.add(mux.addTrack(f));}}
                    first.release();
                }
                mux.start(); long offsetUs=0; ByteBuffer buf=ByteBuffer.allocate(4*1024*1024); MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
                for(Uri uri:mergeUris){long clipMax=0;try(ParcelFileDescriptor fd=getContentResolver().openFileDescriptor(uri,"r")){
                    MediaExtractor ex=new MediaExtractor();ex.setDataSource(fd.getFileDescriptor());int[] map=new int[ex.getTrackCount()];java.util.Arrays.fill(map,-1);
                    for(int t=0;t<ex.getTrackCount();t++){String mime=ex.getTrackFormat(t).getString(MediaFormat.KEY_MIME);for(int m=0;m<outMimes.size();m++)if(outMimes.get(m).equals(mime)){map[t]=outTracks.get(m);ex.selectTrack(t);break;}}
                    while(true){info.offset=0;info.size=ex.readSampleData(buf,0);if(info.size<0)break;int track=ex.getSampleTrackIndex();long sample=ex.getSampleTime();clipMax=Math.max(clipMax,sample);if(track>=0&&map[track]>=0){info.presentationTimeUs=offsetUs+sample;info.flags=ex.getSampleFlags();mux.writeSampleData(map[track],buf,info);}ex.advance();}ex.release();
                }offsetUs+=clipMax+33333;}
                mux.stop();mux.release();mux=null;lastSavedUri=output;runOnUiThread(()->new AlertDialog.Builder(this).setTitle("اكتمل").setMessage("تم دمج الفيديوهات وحفظ النتيجة.").setPositiveButton("حسنًا",null).show());
            }catch(Exception e){if(mux!=null)try{mux.release();}catch(Exception ignored){}runOnUiThread(()->Toast.makeText(this,"تعذر الدمج: يجب أن تكون المقاطع بنفس الدقة والصيغة",Toast.LENGTH_LONG).show());}
        }).start();
    }

    private void showAi(){
        base("توليد فيديو AI");
        root.addView(text("هذه الميزة تحتاج خادمًا آمنًا ومفتاح مزود التوليد. لن نضع المفتاح داخل التطبيق حتى لا تتم سرقته.",17,0xFFE8E3F3));
        EditText prompt=new EditText(this); prompt.setHint("مثال: سيارة رياضية تسير في شوارع الرياض ليلًا"); prompt.setTextColor(Color.WHITE); prompt.setHintTextColor(0xFF8F879E); prompt.setGravity(Gravity.RIGHT); root.addView(prompt,new LinearLayout.LayoutParams(-1,dp(120)));
        Button locked=button("قيد ربط خادم التوليد الآمن"); locked.setEnabled(false); locked.setAlpha(.55f); root.addView(locked);
        root.addView(text("سيُفعّل الزر بعد اختبار التكلفة والنتائج، ثم يحصل أول 30 مستخدمًا على فيديو تجريبي واحد.",14,0xFFBFA9FF));
        Button back=button("العودة للرئيسية"); back.setBackgroundColor(0xFF302843); back.setOnClickListener(v->showHome()); root.addView(back);
    }

    @Override public void onBackPressed(){ showHome(); }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
}
