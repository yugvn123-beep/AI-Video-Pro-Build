package com.smartdailytools.aivideopro;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.media.*;
import android.net.Uri;
import android.os.*;
import android.provider.OpenableColumns;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.nio.ByteBuffer;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_VIDEO = 10, SAVE_VIDEO = 11;
    private final int purple = Color.rgb(124,58,237), ink = Color.rgb(15,11,31);
    private LinearLayout root, editorBox;
    private VideoView videoView;
    private SeekBar startBar, endBar;
    private TextView rangeLabel, status;
    private Uri sourceUri;
    private long durationMs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(ink);
        showHome();
    }

    private TextView text(String value, int sp, int color) {
        TextView v = new TextView(this); v.setText(value); v.setTextSize(sp); v.setTextColor(color);
        v.setGravity(Gravity.RIGHT); v.setPadding(12,10,12,10); return v;
    }

    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextSize(16); b.setTextColor(Color.WHITE);
        b.setBackgroundColor(purple); b.setAllCaps(false); b.setPadding(16,8,16,8);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(54)); p.setMargins(0,8,0,8); b.setLayoutParams(p); return b;
    }

    private void base(String title) {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(ink);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20),dp(22),dp(20),dp(30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); scroll.addView(root);
        TextView logo = text("✦  AI VIDEO PRO",22,Color.WHITE); logo.setTypeface(null,1); root.addView(logo);
        TextView h = text(title,28,Color.WHITE); h.setTypeface(null,1); h.setPadding(12,22,12,8); root.addView(h);
        setContentView(scroll);
    }

    private void showHome() {
        base("أنشئ فيديوك باحتراف");
        root.addView(text("مونتاج سريع وأدوات ذكاء اصطناعي مصممة للمحتوى العربي.",16,0xFFCCC6DD));
        Button edit = button("🎬  قص فيديو من الهاتف"); edit.setOnClickListener(v -> openPicker()); root.addView(edit);
        Button ai = button("✨  توليد فيديو بالذكاء الاصطناعي"); ai.setOnClickListener(v -> showAi()); root.addView(ai);
        root.addView(text("أدوات الإصدار الأول",19,Color.WHITE));
        root.addView(text("✓ استيراد ومعاينة الفيديو\n✓ تحديد البداية والنهاية بدقة\n✓ حفظ نسخة MP4 جديدة\n✓ دون رفع ملفاتك إلى الإنترنت",16,0xFFE8E3F3));
        status = text("الرصيد التجريبي: فيديو AI واحد بعد تفعيل الخادم",14,0xFFBFA9FF); root.addView(status);
    }

    private void openPicker() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.setType("video/*"); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,PICK_VIDEO);
    }

    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req,result,data); if(result!=RESULT_OK || data==null) return;
        if(req==PICK_VIDEO) {
            sourceUri=data.getData(); getContentResolver().takePersistableUriPermission(sourceUri,Intent.FLAG_GRANT_READ_URI_PERMISSION);
            showEditor();
        } else if(req==SAVE_VIDEO) { Uri out=data.getData(); if(out!=null) trimTo(out); }
    }

    private void showEditor() {
        base("قص الفيديو");
        videoView = new VideoView(this);
        videoView.setBackgroundColor(Color.BLACK);
        videoView.setVideoURI(sourceUri);
        videoView.requestFocus();
        root.addView(videoView,new LinearLayout.LayoutParams(-1,dp(260)));
        Button play=button("▶ تشغيل / إيقاف"); play.setOnClickListener(v->{ if(videoView.isPlaying()) videoView.pause(); else videoView.start(); }); root.addView(play);
        rangeLabel=text("جارٍ قراءة مدة الفيديو…",15,Color.WHITE); root.addView(rangeLabel);
        root.addView(text("بداية المقطع",14,0xFFD8D0E8)); startBar=new SeekBar(this); startBar.setMax(1000); root.addView(startBar);
        root.addView(text("نهاية المقطع",14,0xFFD8D0E8)); endBar=new SeekBar(this); endBar.setMax(1000); endBar.setProgress(1000); root.addView(endBar);
        SeekBar.OnSeekBarChangeListener listener=new SeekBar.OnSeekBarChangeListener(){ public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){ videoView.seekTo((int)(durationMs*s.getProgress()/1000)); } public void onProgressChanged(SeekBar s,int p,boolean u){ if(startBar.getProgress()>=endBar.getProgress()){ if(s==startBar) endBar.setProgress(Math.min(1000,p+1)); else startBar.setProgress(Math.max(0,p-1)); } updateRange(); }};
        startBar.setOnSeekBarChangeListener(listener); endBar.setOnSeekBarChangeListener(listener);
        videoView.setOnPreparedListener(mp->{
            durationMs=mp.getDuration();
            videoView.setBackgroundColor(Color.TRANSPARENT);
            videoView.seekTo(1);
            updateRange();
        });
        videoView.setOnErrorListener((mp,what,extra)->{
            rangeLabel.setText("تعذر تشغيل هذا الفيديو. اختر فيديو MP4 مصورًا بكاميرا الهاتف.");
            Toast.makeText(this,"صيغة الفيديو غير مدعومة",Toast.LENGTH_LONG).show();
            return true;
        });
        Button save=button("حفظ الفيديو المقصوص"); save.setOnClickListener(v->requestOutput()); root.addView(save);
        status=text("",14,0xFFBFA9FF); root.addView(status);
        Button back=button("العودة للرئيسية"); back.setBackgroundColor(0xFF302843); back.setOnClickListener(v->showHome()); root.addView(back);
    }

    private void updateRange(){ if(rangeLabel==null||durationMs==0)return; long a=durationMs*startBar.getProgress()/1000,b=durationMs*endBar.getProgress()/1000; rangeLabel.setText("من "+time(a)+" إلى "+time(b)+" — المدة "+time(b-a)); }
    private String time(long ms){return String.format(Locale.US,"%02d:%02d",ms/60000,(ms/1000)%60);}
    private void requestOutput(){ Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT); i.setType("video/mp4"); i.putExtra(Intent.EXTRA_TITLE,"AI_Video_Pro_"+System.currentTimeMillis()+".mp4"); startActivityForResult(i,SAVE_VIDEO); }

    private void trimTo(Uri output) {
        status.setText("جارٍ قص الفيديو… لا تغلق التطبيق");
        final long startUs=durationMs*startBar.getProgress()*1000/1000, endUs=durationMs*endBar.getProgress()*1000/1000;
        new Thread(()->{
            try(ParcelFileDescriptor inFd=getContentResolver().openFileDescriptor(sourceUri,"r"); ParcelFileDescriptor outFd=getContentResolver().openFileDescriptor(output,"rw")){
                MediaExtractor ex=new MediaExtractor(); ex.setDataSource(inFd.getFileDescriptor());
                MediaMuxer mux=new MediaMuxer(outFd.getFileDescriptor(),MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
                int count=ex.getTrackCount(), max=1024*1024; int[] map=new int[count];
                for(int t=0;t<count;t++){MediaFormat f=ex.getTrackFormat(t); map[t]=mux.addTrack(f); if(f.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) max=Math.max(max,f.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE)); ex.selectTrack(t);}
                mux.start(); ex.seekTo(startUs,MediaExtractor.SEEK_TO_PREVIOUS_SYNC); ByteBuffer buf=ByteBuffer.allocate(max); MediaCodec.BufferInfo info=new MediaCodec.BufferInfo();
                while(true){ info.offset=0; info.size=ex.readSampleData(buf,0); if(info.size<0||ex.getSampleTime()>endUs)break; if(ex.getSampleTime()>=startUs){info.presentationTimeUs=ex.getSampleTime()-startUs; info.flags=ex.getSampleFlags(); mux.writeSampleData(map[ex.getSampleTrackIndex()],buf,info);} ex.advance(); }
                mux.stop(); mux.release(); ex.release();
                runOnUiThread(()->{status.setText("تم الحفظ بنجاح ✓"); new AlertDialog.Builder(this).setTitle("اكتمل").setMessage("تم إنشاء الفيديو المقصوص وحفظه في المكان الذي اخترته.").setPositiveButton("حسنًا",null).show();});
            }catch(Exception e){runOnUiThread(()->status.setText("تعذر القص: "+e.getMessage()));}
        }).start();
    }

    private void showAi(){
        base("توليد فيديو AI");
        root.addView(text("هذه الميزة تحتاج خادمًا آمنًا ومفتاح مزود التوليد. لن نضع المفتاح داخل التطبيق حتى لا تتم سرقته.",17,0xFFE8E3F3));
        EditText prompt=new EditText(this); prompt.setHint("مثال: سيارة رياضية تسير في شوارع الرياض ليلًا"); prompt.setTextColor(Color.WHITE); prompt.setHintTextColor(0xFF8F879E); prompt.setGravity(Gravity.RIGHT); root.addView(prompt,new LinearLayout.LayoutParams(-1,dp(120)));
        Button locked=button("قيد ربط خادم التوليد الآمن"); locked.setEnabled(false); locked.setAlpha(.55f); root.addView(locked);
        root.addView(text("سيُفعّل الزر بعد اختبار التكلفة والنتائج، ثم يحصل أول 30 مستخدمًا على فيديو تجريبي واحد.",14,0xFFBFA9FF));
        Button back=button("العودة للرئيسية"); back.setBackgroundColor(0xFF302843); back.setOnClickListener(v->showHome()); root.addView(back);
    }

    @Override public void onBackPressed(){ showHome(); }
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
}
